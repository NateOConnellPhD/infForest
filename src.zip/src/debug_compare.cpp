// debug_compare.cpp — tiny test to compare tree walks
#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
List debug_compare_scorers(
    List cache, List forest, NumericMatrix X_obs, NumericVector y_honest,
    IntegerVector honest_idx, NumericVector ghat,
    int var_col, double val_a, double val_b, int check_tree
) {
    // --- Run cached scorer logic ---
    int n = as<int>(cache["n"]);
    int n_hon = as<int>(cache["n_hon"]);
    IntegerVector tree_offsets_c = as<IntegerVector>(cache["tree_offsets"]);
    IntegerVector flat_sv_c = as<IntegerVector>(cache["flat_sv"]);
    NumericVector flat_sval_c = as<NumericVector>(cache["flat_sval"]);
    IntegerVector flat_lc_c = as<IntegerVector>(cache["flat_lc"]);
    IntegerVector flat_rc_c = as<IntegerVector>(cache["flat_rc"]);
    NumericVector X_row_flat = as<NumericVector>(cache["X_row_flat"]); const double* X_ptr = REAL(X_row_flat); int p = as<int>(cache["p"]);
    IntegerVector obs_leaf_flat_c = as<IntegerVector>(cache["obs_leaf_flat"]);
    NumericVector leaf_mean_flat_c = as<NumericVector>(cache["leaf_mean_flat"]);

    // --- Run old scorer logic ---
    List svl = forest["split.varIDs"];
    List svall = forest["split.values"];
    List chl = forest["child.nodeIDs"];
    const double* Xobs_ptr = REAL(X_obs);
    const double* y_ptr = REAL(y_honest);

    // Compare tree check_tree for first 5 honest obs
    int t0 = check_tree;
    int off = tree_offsets_c[t0];
    const int* sv_c = INTEGER(flat_sv_c) + off;
    const double* sval_c = REAL(flat_sval_c) + off;
    const int* lc_c = INTEGER(flat_lc_c) + off;
    const int* rc_c = INTEGER(flat_rc_c) + off;
    const double* lm_c = REAL(leaf_mean_flat_c) + off;

    IntegerVector sv_old_r = svl[t0]; NumericVector sval_old_r = svall[t0];
    List ch = chl[t0]; IntegerVector lc_old_r = ch[0], rc_old_r = ch[1];
    std::vector<int> sv_o(sv_old_r.begin(), sv_old_r.end());
    std::vector<double> sval_o(sval_old_r.begin(), sval_old_r.end());
    std::vector<int> lc_o(lc_old_r.begin(), lc_old_r.end());
    std::vector<int> rc_o(rc_old_r.begin(), rc_old_r.end());

    // Build old leaf means
    int nn = sv_o.size();
    std::vector<double> leaf_ysum_o(nn, 0.0);
    std::vector<int> leaf_ycnt_o(nn, 0);
    std::vector<int> obs_leaf_o(n_hon);
    for (int j = 0; j < n_hon; j++) {
        int i = honest_idx[j] - 1;
        double yi = y_ptr[i];
        int node = 0;
        while (lc_o[node] != 0 || rc_o[node] != 0)
            node = (Xobs_ptr[i + n * sv_o[node]] <= sval_o[node]) ? lc_o[node] : rc_o[node];
        obs_leaf_o[j] = node;
        if (!ISNA(yi)) { leaf_ysum_o[node] += yi; leaf_ycnt_o[node]++; }
    }
    std::vector<double> lm_o(nn, -1e308);
    for (int nd = 0; nd < nn; nd++)
        if (leaf_ycnt_o[nd] > 0) lm_o[nd] = leaf_ysum_o[nd] / leaf_ycnt_o[nd];

    // Compare for first 5 obs
    int ncheck = std::min(5, n_hon);
    NumericVector old_leaf_a(ncheck), old_leaf_b(ncheck), old_leaf_obs(ncheck);
    NumericVector cached_leaf_a(ncheck), cached_leaf_b(ncheck), cached_leaf_obs(ncheck);
    NumericVector old_lm_a(ncheck), old_lm_b(ncheck), cached_lm_a(ncheck), cached_lm_b(ncheck);
    NumericVector old_obs_leaf_v(ncheck), cached_obs_leaf_v(ncheck);
    NumericVector old_lm_obs(ncheck), cached_lm_obs(ncheck);

    for (int j = 0; j < ncheck; j++) {
        int i = honest_idx[j] - 1;

        // Old obs_leaf
        old_obs_leaf_v[j] = obs_leaf_o[j];
        old_lm_obs[j] = lm_o[obs_leaf_o[j]];

        // Cached obs_leaf
        cached_obs_leaf_v[j] = obs_leaf_flat_c[t0 * n_hon + j];
        cached_lm_obs[j] = lm_c[obs_leaf_flat_c[t0 * n_hon + j]];

        // Old route a
        { int node = 0;
          while (lc_o[node] != 0 || rc_o[node] != 0) {
              double xv = (sv_o[node] == var_col) ? val_a : Xobs_ptr[i + n * sv_o[node]];
              node = (xv <= sval_o[node]) ? lc_o[node] : rc_o[node];
          }
          old_leaf_a[j] = node;
          old_lm_a[j] = lm_o[node];
        }
        // Old route b
        { int node = 0;
          while (lc_o[node] != 0 || rc_o[node] != 0) {
              double xv = (sv_o[node] == var_col) ? val_b : Xobs_ptr[i + n * sv_o[node]];
              node = (xv <= sval_o[node]) ? lc_o[node] : rc_o[node];
          }
          old_leaf_b[j] = node;
          old_lm_b[j] = lm_o[node];
        }

        // Cached route a
        { int node = 0;
          while (lc_c[node] != 0 || rc_c[node] != 0) {
              double xv = (sv_c[node] == var_col) ? val_a : X_ptr[j * p + sv_c[node]];
              node = (xv <= sval_c[node]) ? lc_c[node] : rc_c[node];
          }
          cached_leaf_a[j] = node;
          cached_lm_a[j] = lm_c[node];
        }
        // Cached route b
        { int node = 0;
          while (lc_c[node] != 0 || rc_c[node] != 0) {
              double xv = (sv_c[node] == var_col) ? val_b : X_ptr[j * p + sv_c[node]];
              node = (xv <= sval_c[node]) ? lc_c[node] : rc_c[node];
          }
          cached_leaf_b[j] = node;
          cached_lm_b[j] = lm_c[node];
        }
    }

    return List::create(
        Named("old_obs_leaf") = old_obs_leaf_v,
        Named("cached_obs_leaf") = cached_obs_leaf_v,
        Named("old_lm_obs") = old_lm_obs,
        Named("cached_lm_obs") = cached_lm_obs,
        Named("old_leaf_a") = old_leaf_a,
        Named("cached_leaf_a") = cached_leaf_a,
        Named("old_leaf_b") = old_leaf_b,
        Named("cached_leaf_b") = cached_leaf_b,
        Named("old_lm_a") = old_lm_a,
        Named("cached_lm_a") = cached_lm_a,
        Named("old_lm_b") = old_lm_b,
        Named("cached_lm_b") = cached_lm_b
    );
}

// [[Rcpp::export]]
List debug_tree_walk(List cache, int var_col, double val_a, double val_b, int tree_idx, int obs_idx) {
    IntegerVector tree_offsets = as<IntegerVector>(cache["tree_offsets"]);
    IntegerVector flat_sv = as<IntegerVector>(cache["flat_sv"]);
    NumericVector flat_sval = as<NumericVector>(cache["flat_sval"]);
    IntegerVector flat_lc = as<IntegerVector>(cache["flat_lc"]);
    IntegerVector flat_rc = as<IntegerVector>(cache["flat_rc"]);
    NumericVector X_row_flat = as<NumericVector>(cache["X_row_flat"]); const double* X_ptr = REAL(X_row_flat); int p = as<int>(cache["p"]);
    IntegerVector obs_leaf_flat = as<IntegerVector>(cache["obs_leaf_flat"]);
    NumericVector leaf_mean_flat = as<NumericVector>(cache["leaf_mean_flat"]);
    int n_hon = as<int>(cache["n_hon"]);

    int off = tree_offsets[tree_idx];
    const int* sv = INTEGER(flat_sv) + off;
    const double* sval = REAL(flat_sval) + off;
    const int* lc = INTEGER(flat_lc) + off;
    const int* rc = INTEGER(flat_rc) + off;
    const double* lm = REAL(leaf_mean_flat) + off;

    int j = obs_idx;

    // Actual leaf (from cache)
    int cached_leaf = obs_leaf_flat[tree_idx * n_hon + j];

    // Re-route to actual leaf
    int node_actual = 0;
    IntegerVector path_actual;
    IntegerVector path_sv;
    NumericVector path_xv;
    NumericVector path_sval;
    while (lc[node_actual] != 0 || rc[node_actual] != 0) {
        path_actual.push_back(node_actual);
        path_sv.push_back(sv[node_actual]);
        double xv = X_ptr[j * p + sv[node_actual]];
        path_xv.push_back(xv);
        path_sval.push_back(sval[node_actual]);
        node_actual = (xv <= sval[node_actual]) ? lc[node_actual] : rc[node_actual];
    }

    // Route with a override
    int node_a = 0;
    IntegerVector path_a;
    NumericVector path_a_xv;
    while (lc[node_a] != 0 || rc[node_a] != 0) {
        path_a.push_back(node_a);
        double xv = (sv[node_a] == var_col) ? val_a : X_ptr[j * p + sv[node_a]];
        path_a_xv.push_back(xv);
        node_a = (xv <= sval[node_a]) ? lc[node_a] : rc[node_a];
    }

    // Route with b override
    int node_b = 0;
    IntegerVector path_b;
    NumericVector path_b_xv;
    while (lc[node_b] != 0 || rc[node_b] != 0) {
        path_b.push_back(node_b);
        double xv = (sv[node_b] == var_col) ? val_b : X_ptr[j * p + sv[node_b]];
        path_b_xv.push_back(xv);
        node_b = (xv <= sval[node_b]) ? lc[node_b] : rc[node_b];
    }

    return List::create(
        Named("cached_leaf") = cached_leaf,
        Named("rerouted_leaf") = node_actual,
        Named("leaf_a") = node_a,
        Named("leaf_b") = node_b,
        Named("lm_actual") = lm[cached_leaf],
        Named("lm_a") = lm[node_a],
        Named("lm_b") = lm[node_b],
        Named("path_actual_nodes") = path_actual,
        Named("path_actual_sv") = path_sv,
        Named("path_actual_xv") = path_xv,
        Named("path_actual_sval") = path_sval,
        Named("path_a_nodes") = path_a,
        Named("path_a_xv") = path_a_xv,
        Named("path_b_nodes") = path_b,
        Named("path_b_xv") = path_b_xv,
        Named("var_col") = var_col
    );
}
